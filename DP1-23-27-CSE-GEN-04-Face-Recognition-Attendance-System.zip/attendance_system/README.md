# AttendAI — Face Recognition + Engagement Detection Attendance System

**6CS1991 Design Project–2**  
Team: Nitin Hanumantha Rao · PS Lakshwin Ruup · Royce Biju Thomas · Gokul S  
Mentor: Dr. Ganga Holi

---

## Overview

AttendAI is an enhanced face recognition attendance system that combines:

- **Face Recognition** (Haar Cascade + LBPH) for automatic attendance marking
- **YOLOv8 Engagement Detection** for real-time monitoring of student behaviour
- **Modern Web UI** (Flask + Socket.IO) with live camera streaming

### Engagement Activities Detected
| Label | Description |
|---|---|
| 📱 phone_usage | Student using a phone during class |
| 😴 sleeping | Head down / slouched, inattentive |
| ✋ hand_raising | Student raising hand to ask/answer |
| 👁️ looking_away | Looking away from the board/teacher |
| ✅ attentive | Engaged and focused |

---

## Project Structure

```
attendance_system/
├── app.py                    # Flask + Socket.IO entry point
├── requirements.txt
├── modules/
│   ├── face_recognition_module.py   # Haar + LBPH recognition
│   ├── engagement_module.py         # YOLOv8 engagement detection
│   └── attendance_manager.py        # CSV logging & reporting
├── templates/
│   ├── base.html             # Sidebar layout & shared styles
│   ├── index.html            # Overview / home page
│   ├── dashboard.html        # Live session (camera + feeds)
│   ├── register.html         # Register + train students
│   ├── attendance.html       # View attendance records
│   └── reports.html          # Charts & engagement analytics
└── data/
    ├── student_images/       # Captured face images per student
    ├── training_labels/      # Trained LBPH model (.yml)
    ├── attendance/           # Per-subject CSV files
    ├── engagement/           # Engagement event logs
    └── encodings/            # Pickled label maps
```

---

## Setup & Installation

### 1. Create virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

> **Note:** `ultralytics` will auto-download `yolov8n.pt` (~6MB) on first run.  
> If you don't have a GPU, it runs on CPU — slightly slower but fully functional.

### 3. Run the application
```bash
python app.py
```

Open your browser at: **http://localhost:5000**

---

## Workflow

### Step 1 — Register Students
1. Go to **Register** page
2. Enter Student ID and Full Name
3. Click **Capture Images** — camera opens, captures ~60 face images
4. Repeat for all students

### Step 2 — Train the Model
1. After registering all students, click **Train Model**
2. LBPH model trains on all captured images
3. Saves `lbph_model.yml` + `label_map.pkl` to `data/training_labels/`

### Step 3 — Start Attendance Session
1. Go to **Live Session** (Dashboard)
2. Enter subject name (e.g., "Machine Learning")
3. Click **Start** — camera activates
4. System simultaneously:
   - Recognises faces and marks attendance in CSV
   - Runs YOLOv8 to detect engagement per frame
5. Click **Stop** when done

### Step 4 — View Reports
- **Attendance** page: filter by subject, view records table, export CSV
- **Reports** page: engagement distribution pie chart, attendance bar chart, subject summary

---

## Technology Stack

| Component | Technology |
|---|---|
| Backend | Python 3.10+, Flask, Flask-SocketIO |
| Face Detection | OpenCV Haar Cascade |
| Face Recognition | OpenCV LBPH (Local Binary Pattern Histogram) |
| Engagement Detection | YOLOv8n (Ultralytics) |
| Real-time Streaming | Socket.IO (WebSockets) |
| Frontend | HTML5, CSS3, Vanilla JS, Chart.js |
| Data Storage | CSV files (encrypted future scope) |

---

## Hardware Requirements
- Laptop/PC with webcam
- Minimum 4GB RAM, i3 processor
- Optional: GPU for faster YOLOv8 inference

## Software Requirements
- Python 3.10 or higher
- Libraries: OpenCV, Ultralytics YOLOv8, Flask, NumPy, Pandas

---

## Novelty vs Original System

| Feature | Original | AttendAI |
|---|---|---|
| UI | Tkinter desktop | Modern web dashboard |
| Streaming | OpenCV window | Browser via Socket.IO |
| Engagement | ✗ | ✅ YOLOv8 detection |
| Multi-face | Basic | Simultaneous + feed |
| Reports | CSV only | Charts + analytics |
| Architecture | Monolithic .py | Modular Flask app |

---

## References
1. Golwalkar & Mehendale (2022). Masked-face recognition using deep metric learning. *Applied Intelligence*
2. Alhanaee et al. (2021). Face Recognition Smart Attendance System using Deep Transfer Learning. *Procedia CS*
3. Mahesh et al. (2020). Face Recognition Based Automated Student Attendance. *IJATCSE*
4. Muttaqin et al. (2021). Attendance System using ML-based Face Recognition. *IJCA*
5. Singh & Gupta (2024). Face Recognition Attendance Systems: A Comprehensive Review. *JETA*
